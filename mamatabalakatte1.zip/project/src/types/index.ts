export interface Agent {
  id: string;
  type: 'planner' | 'data' | 'analysis' | 'summary';
  name: string;
  status: 'pending' | 'running' | 'completed' | 'error';
  input?: any;
  output?: any;
  error?: string;
  dependencies?: string[];
  progress?: number;
  fallbackMode?: boolean;
}

export interface ExecutionPlan {
  id: string;
  goal: string;
  agents: Agent[];
  status: 'pending' | 'running' | 'completed' | 'error';
  result?: any;
  startTime?: Date;
  endTime?: Date;
  iterations?: number;
  goalAchieved?: boolean;
  evaluationResult?: GoalEvaluation;
}

export interface PlannerDecision {
  agents: Agent[];
  strategy: string;
  confidence: number;
  estimatedTime: number;
  requiresIteration: boolean;
  isReplan?: boolean;
}

export interface GoalEvaluation {
  achieved: boolean;
  reason: string;
  suggestions?: string[];
  timestamp: Date;
}

export interface APIResponse {
  success: boolean;
  data?: any;
  error?: string;
}

export interface SpaceXLaunch {
  id: string;
  name: string;
  date_utc: string;
  launchpad: string;
  details?: string;
  links: {
    webcast?: string;
    article?: string;
  };
}

export interface WeatherData {
  location: string;
  temperature: number;
  description: string;
  humidity: number;
  windSpeed: number;
  conditions: string;
}

export interface NewsArticle {
  title: string;
  description: string;
  url: string;
  publishedAt: string;
  source: string;
}

export interface EvaluationCase {
  id: string;
  goal: string;
  timestamp: Date;
  executionPlan: ExecutionPlan;
  agentOutputs: Record<string, any>;
  finalResult: any;
  goalAchieved: boolean;
  iterationCount: number;
  totalExecutionTime: number;
  evaluation: {
    agentChaining: boolean;
    dataEnrichment: boolean;
    goalSatisfaction: boolean;
    plannerLogic: boolean;
  };
}