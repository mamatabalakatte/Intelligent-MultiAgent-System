import React, { useState } from 'react';
import { Send, Sparkles, Rocket, Cloud, Newspaper } from 'lucide-react';

interface GoalInputProps {
  onSubmit: (goal: string) => void;
  isExecuting: boolean;
}

const GoalInput: React.FC<GoalInputProps> = ({ onSubmit, isExecuting }) => {
  const [goal, setGoal] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (goal.trim() && !isExecuting) {
      onSubmit(goal.trim());
    }
  };

  const exampleGoals = [
    {
      icon: Rocket,
      text: "Find the next SpaceX launch, check weather at that location, then summarize if it may be delayed",
      color: "from-blue-500 to-purple-600"
    },
    {
      icon: Cloud,
      text: "Get SpaceX launch details and analyze weather conditions for potential delays",
      color: "from-green-500 to-blue-500"
    },
    {
      icon: Newspaper,
      text: "Research upcoming SpaceX mission, gather weather data, and check news for delay factors",
      color: "from-orange-500 to-red-500"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Goal Input Form */}
      <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20 shadow-xl">
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white">Set Your Goal</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <textarea
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              placeholder="Describe what you want to achieve with the multi-agent system..."
              className="w-full h-32 px-4 py-3 bg-black/20 border border-white/20 rounded-lg text-white placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
              disabled={isExecuting}
            />
          </div>

          <button
            type="submit"
            disabled={!goal.trim() || isExecuting}
            className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-medium rounded-lg hover:from-purple-600 hover:to-pink-600 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-transparent disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]"
          >
            {isExecuting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Executing...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Execute Goal</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Example Goals */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white/80">Example Goals</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {exampleGoals.map((example, index) => {
            const Icon = example.icon;
            return (
              <button
                key={index}
                onClick={() => !isExecuting && setGoal(example.text)}
                disabled={isExecuting}
                className="p-4 bg-white/5 backdrop-blur-sm rounded-lg border border-white/10 hover:bg-white/10 transition-all duration-200 text-left group disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className={`inline-flex p-2 rounded-lg bg-gradient-to-r ${example.color} mb-3 group-hover:scale-110 transition-transform duration-200`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <p className="text-sm text-gray-300 leading-relaxed">
                  {example.text}
                </p>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default GoalInput;