import React from 'react';
import { ExecutionPlan } from '../types';
import AgentCard from './AgentCard';
import { ArrowRight, Clock, CheckCircle, AlertCircle } from 'lucide-react';

interface ExecutionFlowProps {
  plan: ExecutionPlan;
}

const ExecutionFlow: React.FC<ExecutionFlowProps> = ({ plan }) => {
  const getStatusColor = (status: ExecutionPlan['status']) => {
    switch (status) {
      case 'completed': return 'text-green-400';
      case 'error': return 'text-red-400';
      case 'running': return 'text-blue-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusIcon = (status: ExecutionPlan['status']) => {
    switch (status) {
      case 'completed': return CheckCircle;
      case 'error': return AlertCircle;
      case 'running': return Clock;
      default: return Clock;
    }
  };

  const StatusIcon = getStatusIcon(plan.status);

  return (
    <div className="space-y-8">
      {/* Execution Header */}
      <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-white">Execution Flow</h2>
          <div className={`flex items-center space-x-2 ${getStatusColor(plan.status)}`}>
            <StatusIcon className="w-5 h-5" />
            <span className="capitalize font-medium">{plan.status}</span>
          </div>
        </div>
        
        <div className="space-y-2">
          <p className="text-gray-300">
            <span className="font-medium">Goal:</span> {plan.goal}
          </p>
          {plan.startTime && (
            <p className="text-gray-400 text-sm">
              <span className="font-medium">Started:</span> {plan.startTime.toLocaleTimeString()}
            </p>
          )}
          {plan.endTime && (
            <p className="text-gray-400 text-sm">
              <span className="font-medium">Completed:</span> {plan.endTime.toLocaleTimeString()}
              <span className="ml-2">
                ({Math.round((plan.endTime.getTime() - plan.startTime!.getTime()) / 1000)}s)
              </span>
            </p>
          )}
        </div>
      </div>

      {/* Agent Flow */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 lg:gap-12">
        {plan.agents.map((agent, index) => (
          <AgentCard key={agent.id} agent={agent} index={index} />
        ))}
      </div>

      {/* Mobile Flow Arrows */}
      <div className="flex justify-center space-x-4 lg:hidden">
        {plan.agents.slice(0, -1).map((_, index) => (
          <ArrowRight key={index} className="text-gray-400 w-6 h-6" />
        ))}
      </div>
    </div>
  );
};

export default ExecutionFlow;