import React from 'react';
import { ExecutionPlan } from '../types';
import { 
  Calendar, 
  MapPin, 
  Thermometer, 
  Wind, 
  AlertTriangle, 
  CheckCircle2,
  Clock,
  TrendingUp
} from 'lucide-react';

interface ResultsSummaryProps {
  plan: ExecutionPlan;
}

const ResultsSummary: React.FC<ResultsSummaryProps> = ({ plan }) => {
  if (plan.status !== 'completed') {
    return null;
  }

  const summaryAgent = plan.agents.find(a => a.id === 'summarizer');
  const weatherAgent = plan.agents.find(a => a.id === 'weather-data');
  const launchAgent = plan.agents.find(a => a.id === 'spacex-data');
  const analysisAgent = plan.agents.find(a => a.id === 'analyzer');

  if (!summaryAgent?.output) {
    return null;
  }

  const summary = summaryAgent.output;
  const weather = weatherAgent?.output;
  const launch = launchAgent?.output;
  const analysis = analysisAgent?.output;

  const getDelayProbabilityColor = (probability: string) => {
    switch (probability) {
      case 'low': return 'text-green-400 bg-green-400/20';
      case 'medium': return 'text-yellow-400 bg-yellow-400/20';
      case 'high': return 'text-red-400 bg-red-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  const getReadinessColor = (readiness: string) => {
    switch (readiness) {
      case 'high': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'low': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Main Summary Card */}
      <div className="bg-gradient-to-br from-white/15 to-white/5 backdrop-blur-md rounded-xl p-8 border border-white/20 shadow-2xl">
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-3 bg-gradient-to-r from-green-500 to-green-600 rounded-full">
            <CheckCircle2 className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white">Mission Analysis Complete</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Launch Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-blue-400" />
              <span>Launch Information</span>
            </h3>
            
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="text-gray-400 min-w-0 flex-1">
                  <p className="font-medium text-white">{summary.launch_details.mission}</p>
                  <p className="text-sm">
                    {new Date(summary.launch_details.date).toLocaleDateString()} at{' '}
                    {new Date(summary.launch_details.date).toLocaleTimeString()}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-gray-400" />
                <span className="text-gray-300">{summary.launch_details.location}</span>
              </div>
            </div>
          </div>

          {/* Weather Impact */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
              <Thermometer className="w-5 h-5 text-orange-400" />
              <span>Weather Impact</span>
            </h3>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-300">Delay Probability</span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getDelayProbabilityColor(summary.weather_impact.delay_probability)}`}>
                  {summary.weather_impact.delay_probability.toUpperCase()}
                </span>
              </div>
              
              {weather && (
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <Thermometer className="w-4 h-4 text-red-400" />
                    <span className="text-gray-300">{weather.temperature}°C</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Wind className="w-4 h-4 text-blue-400" />
                    <span className="text-gray-300">{weather.windSpeed} m/s</span>
                  </div>
                </div>
              )}
              
              <p className="text-gray-300 text-sm leading-relaxed">
                {summary.weather_impact.summary}
              </p>
            </div>
          </div>
        </div>

        {/* Final Recommendation */}
        <div className="mt-8 p-4 bg-black/20 rounded-lg border border-white/10">
          <h4 className="font-semibold text-white mb-2 flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-green-400" />
            <span>Final Recommendation</span>
          </h4>
          <p className="text-gray-300 leading-relaxed">
            {summary.final_recommendation}
          </p>
        </div>
      </div>

      {/* Detailed Analysis */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Launch Readiness */}
        {analysis && (
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
              <Clock className="w-5 h-5 text-purple-400" />
              <span>Launch Readiness</span>
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-300">Overall Readiness</span>
                <span className={`font-medium capitalize ${getReadinessColor(analysis.launchReadiness)}`}>
                  {analysis.launchReadiness}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-300">Confidence Level</span>
                <span className="text-white font-medium">{analysis.confidence}%</span>
              </div>
              
              {analysis.recommendations && analysis.recommendations.length > 0 && (
                <div className="pt-4 border-t border-white/10">
                  <p className="text-sm font-medium text-gray-300 mb-2">Recommendations:</p>
                  <ul className="space-y-1">
                    {analysis.recommendations.slice(0, 3).map((rec: string, index: number) => (
                      <li key={index} className="text-sm text-gray-400 flex items-start space-x-2">
                        <span className="text-blue-400 mt-1">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Key Insights */}
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-yellow-400" />
            <span>Key Insights</span>
          </h3>
          
          <div className="space-y-3">
            {summary.key_insights && summary.key_insights.length > 0 ? (
              summary.key_insights.map((insight: string, index: number) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0" />
                  <p className="text-gray-300 text-sm leading-relaxed">{insight}</p>
                </div>
              ))
            ) : (
              <p className="text-gray-400 text-sm">No specific insights available</p>
            )}
            
            {analysis?.riskFactors && analysis.riskFactors.length > 0 && (
              <div className="pt-4 border-t border-white/10">
                <p className="text-sm font-medium text-red-300 mb-2">Risk Factors:</p>
                <ul className="space-y-1">
                  {analysis.riskFactors.map((risk: string, index: number) => (
                    <li key={index} className="text-sm text-red-200 flex items-start space-x-2">
                      <AlertTriangle className="w-3 h-3 mt-1 flex-shrink-0" />
                      <span>{risk}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultsSummary;