import React from 'react';
import { Agent } from '../types';
import { 
  Brain, 
  Database, 
  BarChart3, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  Clock, 
  Play 
} from 'lucide-react';

interface AgentCardProps {
  agent: Agent;
  index: number;
}

const AgentCard: React.FC<AgentCardProps> = ({ agent, index }) => {
  const getAgentIcon = (type: Agent['type']) => {
    switch (type) {
      case 'planner': return Brain;
      case 'data': return Database;
      case 'analysis': return BarChart3;
      case 'summary': return FileText;
      default: return Brain;
    }
  };

  const getAgentColor = (type: Agent['type']) => {
    switch (type) {
      case 'planner': return 'from-purple-500 to-purple-600';
      case 'data': return 'from-blue-500 to-blue-600';
      case 'analysis': return 'from-green-500 to-green-600';
      case 'summary': return 'from-orange-500 to-orange-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getStatusIcon = (status: Agent['status']) => {
    switch (status) {
      case 'completed': return CheckCircle;
      case 'error': return AlertCircle;
      case 'running': return Play;
      default: return Clock;
    }
  };

  const getStatusColor = (status: Agent['status']) => {
    switch (status) {
      case 'completed': return 'text-green-400';
      case 'error': return 'text-red-400';
      case 'running': return 'text-blue-400';
      default: return 'text-gray-400';
    }
  };

  const Icon = getAgentIcon(agent.type);
  const StatusIcon = getStatusIcon(agent.status);

  return (
    <div 
      className="relative transform transition-all duration-300 hover:scale-105"
      style={{ animationDelay: `${index * 200}ms` }}
    >
      {/* Connection line to next agent */}
      {index < 4 && (
        <div className="absolute top-1/2 -right-6 w-12 h-0.5 bg-gradient-to-r from-gray-300 to-gray-400 hidden lg:block" />
      )}
      
      <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20 shadow-xl hover:shadow-2xl transition-all duration-300">
        {/* Agent Header */}
        <div className="flex items-center justify-between mb-4">
          <div className={`p-3 rounded-full bg-gradient-to-r ${getAgentColor(agent.type)} shadow-lg`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
          <div className={`${getStatusColor(agent.status)}`}>
            <StatusIcon className="w-5 h-5" />
          </div>
        </div>

        {/* Agent Info */}
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-white">{agent.name}</h3>
          <p className="text-sm text-gray-300 capitalize">{agent.status}</p>
          
          {/* Progress Bar */}
          {agent.status === 'running' && typeof agent.progress === 'number' && (
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className={`h-2 rounded-full bg-gradient-to-r ${getAgentColor(agent.type)} transition-all duration-300`}
                style={{ width: `${agent.progress}%` }}
              />
            </div>
          )}

          {/* Agent Output Preview */}
          {agent.output && (
            <div className="mt-4 p-3 bg-black/20 rounded-lg">
              <p className="text-xs text-gray-300 mb-1">Output:</p>
              <p className="text-sm text-white truncate">
                {typeof agent.output === 'object' 
                  ? `${Object.keys(agent.output).length} data points collected`
                  : String(agent.output).substring(0, 50) + '...'
                }
              </p>
            </div>
          )}

          {/* Error Display */}
          {agent.error && (
            <div className="mt-4 p-3 bg-red-500/20 rounded-lg border border-red-500/30">
              <p className="text-xs text-red-300 mb-1">Error:</p>
              <p className="text-sm text-red-200">{agent.error}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AgentCard;