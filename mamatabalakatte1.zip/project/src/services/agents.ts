import { Agent, ExecutionPlan, APIResponse, GoalEvaluation } from '../types';
import { apiService } from './api';
import { plannerAgent } from './planner';
import { evaluationService } from './evaluation';

export class MultiAgentSystem {
  private executionPlan: ExecutionPlan | null = null;
  private onUpdate?: (plan: ExecutionPlan) => void;
  private maxIterations = 3;

  setUpdateCallback(callback: (plan: ExecutionPlan) => void) {
    this.onUpdate = callback;
  }

  async executeGoal(goal: string): Promise<ExecutionPlan> {
    // Initialize execution plan
    this.executionPlan = {
      id: Date.now().toString(),
      goal,
      agents: [],
      status: 'pending',
      startTime: new Date(),
      iterations: 0
    };

    try {
      // Step 1: Create execution plan using Planner Agent
      await this.runPlannerAgent(goal);
      
      // Step 2: Execute agents with iteration support
      await this.executeWithIteration();
      
      // Step 3: Evaluate goal achievement
      await this.evaluateGoalAchievement();
      
      // Step 4: Log evaluation case
      await this.logEvaluationCase();
      
    } catch (error) {
      this.executionPlan.status = 'error';
      console.error('Execution error:', error);
    }

    return this.executionPlan;
  }

  private async runPlannerAgent(goal: string): Promise<void> {
    const plannerAgentInstance: Agent = {
      id: 'planner',
      type: 'planner',
      name: 'Strategic Planner',
      status: 'running',
      progress: 0
    };

    this.executionPlan!.agents.push(plannerAgentInstance);
    this.notifyUpdate();

    // Simulate planning process
    await this.delay(1000);
    plannerAgentInstance.progress = 50;
    this.notifyUpdate();

    // Use Planner Agent to analyze goal
    const plannerDecision = plannerAgent.analyzeGoal(goal);
    
    // Add planned agents to execution plan
    this.executionPlan!.agents.push(...plannerDecision.agents);
    
    plannerAgentInstance.status = 'completed';
    plannerAgentInstance.progress = 100;
    plannerAgentInstance.output = {
      strategy: plannerDecision.strategy,
      agentCount: plannerDecision.agents.length,
      estimatedTime: plannerDecision.estimatedTime,
      confidence: plannerDecision.confidence,
      requiresIteration: plannerDecision.requiresIteration
    };
    
    this.notifyUpdate();
  }

  private async executeWithIteration(): Promise<void> {
    let currentIteration = 0;
    let goalAchieved = false;

    while (currentIteration < this.maxIterations && !goalAchieved) {
      currentIteration++;
      this.executionPlan!.iterations = currentIteration;
      
      console.log(`Starting iteration ${currentIteration}`);
      
      // Execute agent chain
      await this.executeAgentChain();
      
      // Check if goal is achieved
      const evaluation = plannerAgent.evaluateGoalAchievement(this.executionPlan!);
      goalAchieved = evaluation.achieved;
      
      if (!goalAchieved && currentIteration < this.maxIterations) {
        console.log(`Goal not achieved: ${evaluation.reason}. Replanning...`);
        
        // Replan and update agents
        const replanDecision = plannerAgent.replan(this.executionPlan!, evaluation.reason);
        
        // Reset agents for next iteration
        this.executionPlan!.agents = [
          this.executionPlan!.agents[0], // Keep planner
          ...replanDecision.agents
        ];
        
        // Reset agent statuses
        this.executionPlan!.agents.forEach(agent => {
          if (agent.id !== 'planner') {
            agent.status = 'pending';
            agent.error = undefined;
            agent.progress = 0;
          }
        });
        
        this.notifyUpdate();
        await this.delay(1000); // Brief pause between iterations
      }
    }

    this.executionPlan!.status = goalAchieved ? 'completed' : 'error';
    this.executionPlan!.endTime = new Date();
    this.executionPlan!.goalAchieved = goalAchieved;
  }

  private async executeAgentChain(): Promise<void> {
    const agents = this.executionPlan!.agents.filter(a => a.id !== 'planner');
    
    for (const agent of agents) {
      // Skip if already completed in previous iteration
      if (agent.status === 'completed') continue;
      
      // Check if dependencies are met
      if (agent.dependencies) {
        const dependenciesMet = agent.dependencies.every(depId => {
          const depAgent = this.executionPlan!.agents.find(a => a.id === depId);
          return depAgent?.status === 'completed';
        });
        
        if (!dependenciesMet) {
          agent.status = 'error';
          agent.error = 'Dependencies not met';
          continue;
        }
      }

      await this.executeAgent(agent);
    }
  }

  private async executeAgent(agent: Agent): Promise<void> {
    agent.status = 'running';
    agent.progress = 0;
    this.notifyUpdate();

    try {
      await this.delay(500);
      agent.progress = 25;
      this.notifyUpdate();

      // Get input from dependent agents
      const input = this.gatherAgentInput(agent);
      agent.input = input;

      await this.delay(500);
      agent.progress = 50;
      this.notifyUpdate();

      // Execute agent logic
      let result: APIResponse;
      switch (agent.id) {
        case 'spacex-data':
          result = await apiService.getNextSpaceXLaunch();
          break;
        case 'weather-data':
          const launchData = input.launch || input['spacex-data'];
          if (agent.fallbackMode || !launchData?.location) {
            // Use fallback mock data
            result = await apiService.getMockWeatherData();
          } else {
            result = await apiService.getWeatherData(
              launchData.location.latitude,
              launchData.location.longitude,
              launchData.location.name
            );
          }
          break;
        case 'news-data':
          const launchInfo = input.launch || input['spacex-data'];
          result = await apiService.getNewsAboutSpaceX(launchInfo?.launch?.name || 'SpaceX');
          break;
        case 'analyzer':
          result = this.analyzeData(input);
          break;
        case 'summarizer':
          result = this.summarizeFindings(input);
          break;
        default:
          throw new Error(`Unknown agent: ${agent.id}`);
      }

      await this.delay(500);
      agent.progress = 75;
      this.notifyUpdate();

      if (result.success) {
        agent.output = result.data;
        agent.status = 'completed';
        agent.progress = 100;
      } else {
        agent.status = 'error';
        agent.error = result.error;
      }

    } catch (error) {
      agent.status = 'error';
      agent.error = error instanceof Error ? error.message : 'Unknown error';
    }

    this.notifyUpdate();
  }

  private async evaluateGoalAchievement(): Promise<void> {
    const evaluation = plannerAgent.evaluateGoalAchievement(this.executionPlan!);
    this.executionPlan!.evaluationResult = {
      ...evaluation,
      timestamp: new Date()
    };
    this.executionPlan!.goalAchieved = evaluation.achieved;
  }

  private async logEvaluationCase(): Promise<void> {
    if (this.executionPlan) {
      await evaluationService.logEvaluationCase(this.executionPlan);
    }
  }

  private gatherAgentInput(agent: Agent): any {
    if (!agent.dependencies) return {};

    const input: any = {};
    
    for (const depId of agent.dependencies) {
      const depAgent = this.executionPlan!.agents.find(a => a.id === depId);
      if (depAgent?.output) {
        input[depId] = depAgent.output;
        
        // Flatten launch data for easier access
        if (depId === 'spacex-data') {
          input.launch = depAgent.output;
        }
      }
    }

    return input;
  }

  private analyzeData(input: any): APIResponse {
    try {
      const analysis = {
        launchReadiness: this.assessLaunchReadiness(input),
        riskFactors: this.identifyRiskFactors(input),
        recommendations: this.generateRecommendations(input),
        confidence: this.calculateConfidence(input),
        dataQuality: this.assessDataQuality(input)
      };

      return { success: true, data: analysis };
    } catch (error) {
      return { success: false, error: 'Analysis failed' };
    }
  }

  private summarizeFindings(input: any): APIResponse {
    try {
      const analysis = input.analyzer;
      const launch = input['spacex-data'];
      const weather = input['weather-data'];
      const news = input['news-data'];

      const summary = {
        goal_achievement: 'completed',
        launch_details: {
          mission: launch?.launch?.name || 'Unknown Mission',
          date: launch?.launch?.date_utc || 'TBD',
          location: launch?.location?.name || 'Unknown Location'
        },
        weather_impact: {
          conditions: weather?.conditions || 'unknown',
          delay_probability: this.calculateDelayProbability(weather, analysis),
          summary: this.generateWeatherSummary(weather)
        },
        key_insights: this.extractKeyInsights(analysis, news, launch, weather),
        final_recommendation: this.generateFinalRecommendation(analysis, weather),
        data_sources_used: this.getDataSourcesSummary(input),
        confidence_score: analysis?.confidence || 0
      };

      return { success: true, data: summary };
    } catch (error) {
      return { success: false, error: 'Summary generation failed' };
    }
  }

  // Helper methods for analysis
  private assessLaunchReadiness(input: any): string {
    const weather = input['weather-data'];
    if (!weather) return 'insufficient_data';
    
    switch (weather.conditions) {
      case 'favorable': return 'high';
      case 'moderate': return 'medium';
      case 'challenging': return 'low';
      default: return 'unknown';
    }
  }

  private identifyRiskFactors(input: any): string[] {
    const risks: string[] = [];
    const weather = input['weather-data'];
    
    if (weather) {
      if (weather.windSpeed > 15) risks.push('High wind speeds');
      if (weather.humidity > 80) risks.push('High humidity');
      if (weather.temperature < 5) risks.push('Low temperature');
      if (weather.description.includes('rain')) risks.push('Precipitation');
    }
    
    return risks;
  }

  private generateRecommendations(input: any): string[] {
    const recommendations: string[] = [];
    const weather = input['weather-data'];
    
    if (weather?.conditions === 'challenging') {
      recommendations.push('Consider delaying launch until conditions improve');
    }
    if (weather?.windSpeed > 10) {
      recommendations.push('Monitor wind conditions closely');
    }
    
    recommendations.push('Continue monitoring weather updates');
    recommendations.push('Maintain communication with mission control');
    
    return recommendations;
  }

  private calculateConfidence(input: any): number {
    let confidence = 100;
    
    // Reduce confidence based on data availability
    if (!input['spacex-data']) confidence -= 30;
    if (!input['weather-data']) confidence -= 30;
    if (!input['news-data']) confidence -= 20;
    
    // Reduce confidence based on weather conditions
    const weather = input['weather-data'];
    if (weather?.conditions === 'challenging') confidence -= 20;
    if (weather?.conditions === 'moderate') confidence -= 10;
    
    return Math.max(confidence, 0);
  }

  private assessDataQuality(input: any): { score: number; issues: string[] } {
    let score = 100;
    const issues: string[] = [];
    
    if (!input['spacex-data']) {
      score -= 40;
      issues.push('Missing SpaceX launch data');
    }
    
    if (!input['weather-data']) {
      score -= 30;
      issues.push('Missing weather data');
    }
    
    if (!input['news-data']) {
      score -= 20;
      issues.push('Missing news data');
    }
    
    return { score: Math.max(score, 0), issues };
  }

  private calculateDelayProbability(weather: any, analysis: any): string {
    if (!weather) return 'unknown';
    
    const risks = analysis?.riskFactors?.length || 0;
    if (weather.conditions === 'challenging' || risks > 2) return 'high';
    if (weather.conditions === 'moderate' || risks > 0) return 'medium';
    return 'low';
  }

  private generateWeatherSummary(weather: any): string {
    if (!weather) return 'Weather data unavailable';
    
    return `${weather.description} with ${weather.temperature}°C, ${weather.windSpeed} m/s winds, and ${weather.humidity}% humidity. Conditions are ${weather.conditions} for launch operations.`;
  }

  private extractKeyInsights(analysis: any, news: any, launch: any, weather: any): string[] {
    const insights: string[] = [];
    
    if (analysis?.launchReadiness === 'high') {
      insights.push('Launch conditions appear favorable');
    }
    
    if (analysis?.riskFactors?.length > 0) {
      insights.push(`${analysis.riskFactors.length} potential risk factors identified`);
    }
    
    if (news && Array.isArray(news) && news.length > 0) {
      insights.push(`${news.length} recent news articles provide additional context`);
    }
    
    if (launch?.launch?.date_utc) {
      const launchDate = new Date(launch.launch.date_utc);
      const daysUntilLaunch = Math.ceil((launchDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
      insights.push(`Launch scheduled in ${daysUntilLaunch} days`);
    }
    
    return insights;
  }

  private generateFinalRecommendation(analysis: any, weather: any): string {
    if (!analysis || !weather) {
      return 'Insufficient data to make a reliable recommendation';
    }
    
    if (analysis.launchReadiness === 'high' && weather.conditions === 'favorable') {
      return 'Launch is likely to proceed as scheduled with minimal risk of weather delays';
    }
    
    if (analysis.launchReadiness === 'low' || weather.conditions === 'challenging') {
      return 'High probability of launch delay due to unfavorable conditions';
    }
    
    return 'Launch may proceed with close monitoring of conditions';
  }

  private getDataSourcesSummary(input: any): string[] {
    const sources: string[] = [];
    
    if (input['spacex-data']) sources.push('SpaceX API');
    if (input['weather-data']) sources.push('Weather API');
    if (input['news-data']) sources.push('News API');
    
    return sources;
  }

  private notifyUpdate(): void {
    if (this.onUpdate && this.executionPlan) {
      this.onUpdate({ ...this.executionPlan });
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const multiAgentSystem = new MultiAgentSystem();