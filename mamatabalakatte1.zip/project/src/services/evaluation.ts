import { ExecutionPlan, EvaluationCase } from '../types';

class EvaluationService {
  private evaluationCases: EvaluationCase[] = [];

  async logEvaluationCase(plan: ExecutionPlan): Promise<void> {
    const evaluationCase: EvaluationCase = {
      id: `eval-${Date.now()}`,
      goal: plan.goal,
      timestamp: new Date(),
      executionPlan: plan,
      agentOutputs: this.extractAgentOutputs(plan),
      finalResult: this.extractFinalResult(plan),
      goalAchieved: plan.goalAchieved || false,
      iterationCount: plan.iterations || 1,
      totalExecutionTime: this.calculateExecutionTime(plan),
      evaluation: {
        agentChaining: this.evaluateAgentChaining(plan),
        dataEnrichment: this.evaluateDataEnrichment(plan),
        goalSatisfaction: plan.goalAchieved || false,
        plannerLogic: this.evaluatePlannerLogic(plan)
      }
    };

    this.evaluationCases.push(evaluationCase);
    
    // Save to localStorage for persistence
    this.saveEvaluationCase(evaluationCase);
    
    console.log('Evaluation case logged:', evaluationCase);
  }

  private extractAgentOutputs(plan: ExecutionPlan): Record<string, any> {
    const outputs: Record<string, any> = {};
    
    plan.agents.forEach(agent => {
      if (agent.output) {
        outputs[agent.id] = {
          type: agent.type,
          name: agent.name,
          status: agent.status,
          output: agent.output,
          executionTime: this.estimateAgentExecutionTime(agent)
        };
      }
    });
    
    return outputs;
  }

  private extractFinalResult(plan: ExecutionPlan): any {
    const summaryAgent = plan.agents.find(a => a.type === 'summary');
    return summaryAgent?.output || null;
  }

  private calculateExecutionTime(plan: ExecutionPlan): number {
    if (plan.startTime && plan.endTime) {
      return plan.endTime.getTime() - plan.startTime.getTime();
    }
    return 0;
  }

  private evaluateAgentChaining(plan: ExecutionPlan): boolean {
    // Check if agents have proper dependencies and data flow
    const dataAgents = plan.agents.filter(a => a.type === 'data');
    const analysisAgents = plan.agents.filter(a => a.type === 'analysis');
    const summaryAgents = plan.agents.filter(a => a.type === 'summary');
    
    // Must have at least one data agent feeding into analysis/summary
    if (dataAgents.length === 0) return false;
    
    // Check if analysis agents depend on data agents
    if (analysisAgents.length > 0) {
      const analysisHasDataDependency = analysisAgents.some(agent => 
        agent.dependencies?.some(dep => 
          plan.agents.find(a => a.id === dep)?.type === 'data'
        )
      );
      if (!analysisHasDataDependency) return false;
    }
    
    // Check if summary agents depend on other agents
    if (summaryAgents.length > 0) {
      const summaryHasDependency = summaryAgents.some(agent => 
        agent.dependencies && agent.dependencies.length > 0
      );
      if (!summaryHasDependency) return false;
    }
    
    return true;
  }

  private evaluateDataEnrichment(plan: ExecutionPlan): boolean {
    // Check if each agent adds value to the data pipeline
    const completedAgents = plan.agents.filter(a => a.status === 'completed' && a.output);
    
    if (completedAgents.length < 2) return false;
    
    // Check if later agents reference earlier agents' outputs
    for (let i = 1; i < completedAgents.length; i++) {
      const agent = completedAgents[i];
      if (agent.dependencies && agent.dependencies.length > 0) {
        // This agent depends on others, which is good for enrichment
        continue;
      } else if (agent.type === 'summary' || agent.type === 'analysis') {
        // Summary and analysis agents should always have dependencies
        return false;
      }
    }
    
    return true;
  }

  private evaluatePlannerLogic(plan: ExecutionPlan): boolean {
    const plannerAgent = plan.agents.find(a => a.type === 'planner');
    
    if (!plannerAgent || plannerAgent.status !== 'completed') return false;
    
    // Check if planner output contains strategy and agent planning
    const plannerOutput = plannerAgent.output;
    if (!plannerOutput || !plannerOutput.strategy || !plannerOutput.agentCount) {
      return false;
    }
    
    // Check if the planned agents were actually created
    const plannedAgentCount = plannerOutput.agentCount;
    const actualAgentCount = plan.agents.length - 1; // Exclude planner itself
    
    return actualAgentCount >= plannedAgentCount;
  }

  private estimateAgentExecutionTime(agent: any): number {
    // Rough estimation based on agent type
    switch (agent.type) {
      case 'planner': return 1000;
      case 'data': return 2000;
      case 'analysis': return 1500;
      case 'summary': return 1000;
      default: return 1000;
    }
  }

  private saveEvaluationCase(evaluationCase: EvaluationCase): void {
    try {
      const existingCases = this.loadEvaluationCases();
      existingCases.push(evaluationCase);
      
      // Keep only the last 10 evaluation cases
      const recentCases = existingCases.slice(-10);
      
      localStorage.setItem('multiAgentEvaluations', JSON.stringify(recentCases));
    } catch (error) {
      console.error('Failed to save evaluation case:', error);
    }
  }

  private loadEvaluationCases(): EvaluationCase[] {
    try {
      const stored = localStorage.getItem('multiAgentEvaluations');
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Failed to load evaluation cases:', error);
      return [];
    }
  }

  getEvaluationCases(): EvaluationCase[] {
    return [...this.evaluationCases, ...this.loadEvaluationCases()];
  }

  generateEvaluationReport(): string {
    const cases = this.getEvaluationCases();
    
    if (cases.length === 0) {
      return 'No evaluation cases available';
    }
    
    const successRate = cases.filter(c => c.goalAchieved).length / cases.length;
    const avgIterations = cases.reduce((sum, c) => sum + c.iterationCount, 0) / cases.length;
    const avgExecutionTime = cases.reduce((sum, c) => sum + c.totalExecutionTime, 0) / cases.length;
    
    return `
Evaluation Report:
- Total Cases: ${cases.length}
- Success Rate: ${(successRate * 100).toFixed(1)}%
- Average Iterations: ${avgIterations.toFixed(1)}
- Average Execution Time: ${(avgExecutionTime / 1000).toFixed(1)}s
- Agent Chaining Success: ${cases.filter(c => c.evaluation.agentChaining).length}/${cases.length}
- Data Enrichment Success: ${cases.filter(c => c.evaluation.dataEnrichment).length}/${cases.length}
    `.trim();
  }
}

export const evaluationService = new EvaluationService();