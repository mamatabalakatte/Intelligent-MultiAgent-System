import axios from 'axios';
import { APIResponse, SpaceXLaunch, WeatherData, NewsArticle } from '../types';

const SPACEX_API = 'https://api.spacexdata.com/v4';
const OPENWEATHER_API = 'https://api.openweathermap.org/data/2.5';
const NEWS_API = 'https://newsapi.org/v2';

class APIService {
  private weatherApiKey = import.meta.env.VITE_OPENWEATHER_API_KEY || 'demo_key';
  private newsApiKey = import.meta.env.VITE_NEWS_API_KEY || 'demo_key';

  async getNextSpaceXLaunch(): Promise<APIResponse> {
    try {
      const response = await axios.get(`${SPACEX_API}/launches/upcoming`);
      const launches = response.data;
      
      if (launches.length === 0) {
        return this.getMockSpaceXData();
      }

      const nextLaunch = launches[0];
      
      // Get launchpad details
      const launchpadResponse = await axios.get(`${SPACEX_API}/launchpads/${nextLaunch.launchpad}`);
      const launchpad = launchpadResponse.data;

      const launchData: SpaceXLaunch = {
        id: nextLaunch.id,
        name: nextLaunch.name,
        date_utc: nextLaunch.date_utc,
        launchpad: nextLaunch.launchpad,
        details: nextLaunch.details,
        links: nextLaunch.links || {}
      };

      return {
        success: true,
        data: {
          launch: launchData,
          location: {
            name: launchpad.full_name,
            latitude: launchpad.latitude,
            longitude: launchpad.longitude,
            region: launchpad.region
          }
        }
      };
    } catch (error) {
      console.error('SpaceX API Error:', error);
      return this.getMockSpaceXData();
    }
  }

  async getWeatherData(lat: number, lon: number, locationName: string): Promise<APIResponse> {
    try {
      // For demo purposes, we'll use mock data since API keys might not be available
      if (this.weatherApiKey === 'demo_key') {
        return this.getMockWeatherData(locationName);
      }

      const response = await axios.get(
        `${OPENWEATHER_API}/weather?lat=${lat}&lon=${lon}&appid=${this.weatherApiKey}&units=metric`
      );

      const weather = response.data;
      const weatherData: WeatherData = {
        location: locationName,
        temperature: Math.round(weather.main.temp),
        description: weather.weather[0].description,
        humidity: weather.main.humidity,
        windSpeed: weather.wind.speed,
        conditions: this.assessLaunchConditions(weather)
      };

      return { success: true, data: weatherData };
    } catch (error) {
      console.error('Weather API Error:', error);
      return this.getMockWeatherData(locationName);
    }
  }

  async getMockWeatherData(locationName?: string): Promise<APIResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const conditions = ['favorable', 'moderate', 'challenging'];
    const descriptions = ['Clear skies', 'Partly cloudy', 'Overcast', 'Light rain', 'Scattered clouds'];
    const selectedCondition = conditions[Math.floor(Math.random() * conditions.length)];
    
    const mockWeather: WeatherData = {
      location: locationName || 'Kennedy Space Center',
      temperature: Math.floor(Math.random() * 25) + 15, // 15-40°C
      description: descriptions[Math.floor(Math.random() * descriptions.length)],
      humidity: Math.floor(Math.random() * 40) + 40, // 40-80%
      windSpeed: Math.floor(Math.random() * 20) + 5, // 5-25 m/s
      conditions: selectedCondition
    };
    
    return { success: true, data: mockWeather };
  }

  async getNewsAboutSpaceX(launchName: string): Promise<APIResponse> {
    try {
      // For demo purposes, we'll use mock data
      if (this.newsApiKey === 'demo_key') {
        return this.getMockNewsData(launchName);
      }

      const response = await axios.get(
        `${NEWS_API}/everything?q=spacex ${launchName}&sortBy=publishedAt&pageSize=5&apiKey=${this.newsApiKey}`
      );

      const articles = response.data.articles.map((article: any): NewsArticle => ({
        title: article.title,
        description: article.description,
        url: article.url,
        publishedAt: article.publishedAt,
        source: article.source.name
      }));

      return { success: true, data: articles };
    } catch (error) {
      console.error('News API Error:', error);
      return this.getMockNewsData(launchName);
    }
  }

  private async getMockSpaceXData(): Promise<APIResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const mockLaunch: SpaceXLaunch = {
      id: 'mock-launch-001',
      name: 'Starlink 6-34',
      date_utc: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days from now
      launchpad: 'ksc_lc_39a',
      details: 'SpaceX will launch the next batch of Starlink satellites to low Earth orbit.',
      links: {
        webcast: 'https://www.youtube.com/watch?v=example',
        article: 'https://www.spacex.com/launches/'
      }
    };

    return {
      success: true,
      data: {
        launch: mockLaunch,
        location: {
          name: 'Kennedy Space Center LC-39A',
          latitude: 28.6080585,
          longitude: -80.6039558,
          region: 'Florida'
        }
      }
    };
  }

  private async getMockNewsData(launchName: string): Promise<APIResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 600));
    
    const mockNews: NewsArticle[] = [
      {
        title: `${launchName} Launch Preparations Continue at Kennedy Space Center`,
        description: 'SpaceX teams are conducting final preparations for the upcoming launch with all systems showing nominal status.',
        url: 'https://example.com/news1',
        publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
        source: 'SpaceNews'
      },
      {
        title: 'Weather Forecast Looking Favorable for SpaceX Launch',
        description: 'Meteorologists report improving weather conditions for the scheduled SpaceX mission this week.',
        url: 'https://example.com/news2',
        publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(), // 6 hours ago
        source: 'Space Weather'
      },
      {
        title: 'SpaceX Mission Timeline and Key Objectives Revealed',
        description: 'Detailed breakdown of mission objectives and timeline for the upcoming Starlink deployment.',
        url: 'https://example.com/news3',
        publishedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(), // 12 hours ago
        source: 'SpaceflightNow'
      },
      {
        title: 'Falcon 9 Booster Successfully Completes Pre-Launch Testing',
        description: 'The Falcon 9 first stage has completed all pre-flight checks and is ready for the upcoming mission.',
        url: 'https://example.com/news4',
        publishedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
        source: 'SpaceX Updates'
      }
    ];
    
    return { success: true, data: mockNews };
  }

  private assessLaunchConditions(weather: any): string {
    const temp = weather.main.temp;
    const windSpeed = weather.wind.speed;
    const humidity = weather.main.humidity;
    
    if (windSpeed > 15 || temp < 5 || temp > 35 || humidity > 90) {
      return 'challenging';
    } else if (windSpeed > 10 || temp < 10 || humidity > 80) {
      return 'moderate';
    }
    return 'favorable';
  }
}

export const apiService = new APIService();