import { Agent, ExecutionPlan, PlannerDecision } from '../types';

export class PlannerAgent {
  private static instance: PlannerAgent;
  
  static getInstance(): PlannerAgent {
    if (!PlannerAgent.instance) {
      PlannerAgent.instance = new PlannerAgent();
    }
    return PlannerAgent.instance;
  }

  /**
   * Analyzes user goal and creates an execution plan
   */
  analyzeGoal(goal: string): PlannerDecision {
    const normalizedGoal = goal.toLowerCase();
    const agents: Agent[] = [];
    let strategy = '';
    let confidence = 0.9;

    // Goal analysis patterns
    const patterns = {
      spacex: /spacex|launch|rocket|mission/i,
      weather: /weather|temperature|wind|rain|conditions/i,
      news: /news|delay|update|report|article/i,
      analysis: /analyze|compare|evaluate|assess|summarize/i,
      delay: /delay|postpone|reschedule|cancel/i
    };

    // Determine required agents based on goal content
    if (patterns.spacex.test(goal)) {
      agents.push(this.createAgent('spacex-data', 'data', 'SpaceX Data Collector', ['planner']));
      strategy += 'Collect SpaceX launch information. ';
    }

    if (patterns.weather.test(goal)) {
      const dependencies = agents.length > 0 ? [agents[agents.length - 1].id] : ['planner'];
      agents.push(this.createAgent('weather-data', 'data', 'Weather Analyst', dependencies));
      strategy += 'Analyze weather conditions at launch location. ';
    }

    if (patterns.news.test(goal)) {
      const dependencies = agents.length > 0 ? [agents[0].id] : ['planner'];
      agents.push(this.createAgent('news-data', 'data', 'News Aggregator', dependencies));
      strategy += 'Gather relevant news and updates. ';
    }

    // Always add analysis if we have multiple data sources
    if (agents.length > 1) {
      const dataDependencies = agents.map(a => a.id);
      agents.push(this.createAgent('analyzer', 'analysis', 'Data Synthesizer', dataDependencies));
      strategy += 'Synthesize collected data for insights. ';
    }

    // Always add summary agent
    const summaryDependencies = agents.length > 0 ? [agents[agents.length - 1].id] : ['planner'];
    agents.push(this.createAgent('summarizer', 'summary', 'Goal Achiever', summaryDependencies));
    strategy += 'Provide final recommendations and achieve stated goal.';

    // Adjust confidence based on goal complexity
    if (agents.length < 3) confidence -= 0.1;
    if (!patterns.spacex.test(goal)) confidence -= 0.2;

    return {
      agents,
      strategy,
      confidence,
      estimatedTime: agents.length * 2,
      requiresIteration: patterns.delay.test(goal) || patterns.analysis.test(goal)
    };
  }

  /**
   * Evaluates if the goal has been achieved
   */
  evaluateGoalAchievement(plan: ExecutionPlan): { achieved: boolean; reason: string; suggestions?: string[] } {
    const completedAgents = plan.agents.filter(a => a.status === 'completed');
    const failedAgents = plan.agents.filter(a => a.status === 'error');
    
    // Check if all agents completed successfully
    if (failedAgents.length > 0) {
      return {
        achieved: false,
        reason: `${failedAgents.length} agent(s) failed to complete their tasks`,
        suggestions: [
          'Retry failed agents with different parameters',
          'Skip optional data sources and proceed with available data',
          'Simplify the goal to focus on core requirements'
        ]
      };
    }

    // Check if we have a summary output
    const summaryAgent = plan.agents.find(a => a.type === 'summary');
    if (!summaryAgent?.output) {
      return {
        achieved: false,
        reason: 'No final summary was generated',
        suggestions: ['Ensure summary agent has access to all required data']
      };
    }

    // Analyze goal-specific requirements
    const goalLower = plan.goal.toLowerCase();
    const summary = summaryAgent.output;

    // Check for delay analysis if requested
    if (goalLower.includes('delay') && !summary.weather_impact?.delay_probability) {
      return {
        achieved: false,
        reason: 'Delay analysis was requested but not provided',
        suggestions: ['Ensure weather data is available for delay assessment']
      };
    }

    // Check for launch information if requested
    if (goalLower.includes('launch') && !summary.launch_details?.mission) {
      return {
        achieved: false,
        reason: 'Launch information was requested but not found',
        suggestions: ['Verify SpaceX API connectivity and data availability']
      };
    }

    return {
      achieved: true,
      reason: 'All required information gathered and goal successfully achieved'
    };
  }

  /**
   * Creates a new execution plan when iteration is needed
   */
  replan(originalPlan: ExecutionPlan, failureReason: string): PlannerDecision {
    console.log(`Replanning due to: ${failureReason}`);
    
    // Analyze what went wrong and adjust strategy
    const failedAgents = originalPlan.agents.filter(a => a.status === 'error');
    const newAgents: Agent[] = [];
    
    // Keep successful agents and replace failed ones
    for (const agent of originalPlan.agents) {
      if (agent.status === 'completed') {
        newAgents.push({ ...agent, status: 'pending' }); // Reset for re-execution
      } else if (agent.status === 'error') {
        // Try alternative approach for failed agents
        if (agent.id === 'weather-data') {
          // Use mock weather data if API fails
          newAgents.push({
            ...agent,
            status: 'pending',
            name: 'Weather Analyst (Fallback)',
            fallbackMode: true
          });
        } else if (agent.id === 'news-data') {
          // Skip news if not critical
          continue;
        } else {
          // Retry with same configuration
          newAgents.push({ ...agent, status: 'pending', error: undefined });
        }
      } else {
        newAgents.push(agent);
      }
    }

    return {
      agents: newAgents,
      strategy: `Replanned execution: ${failureReason}. Adjusted agent configuration for better reliability.`,
      confidence: 0.7, // Lower confidence for replanned execution
      estimatedTime: newAgents.length * 1.5,
      requiresIteration: false, // Avoid infinite loops
      isReplan: true
    };
  }

  private createAgent(id: string, type: Agent['type'], name: string, dependencies: string[]): Agent {
    return {
      id,
      type,
      name,
      status: 'pending',
      dependencies
    };
  }
}

export const plannerAgent = PlannerAgent.getInstance();