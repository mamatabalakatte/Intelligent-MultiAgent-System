import React, { useState, useCallback } from 'react';
import { ExecutionPlan } from './types';
import { multiAgentSystem } from './services/agents';
import GoalInput from './components/GoalInput';
import ExecutionFlow from './components/ExecutionFlow';
import ResultsSummary from './components/ResultsSummary';
import { Brain, Github, ExternalLink } from 'lucide-react';

function App() {
  const [currentPlan, setCurrentPlan] = useState<ExecutionPlan | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);

  const handleGoalSubmit = useCallback(async (goal: string) => {
    setIsExecuting(true);
    setCurrentPlan(null);

    // Set up real-time updates
    multiAgentSystem.setUpdateCallback((plan) => {
      setCurrentPlan(plan);
    });

    try {
      const plan = await multiAgentSystem.executeGoal(goal);
      setCurrentPlan(plan);
    } catch (error) {
      console.error('Execution failed:', error);
    } finally {
      setIsExecuting(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%239C92AC%22 fill-opacity=%220.05%22%3E%3Ccircle cx=%2230%22 cy=%2230%22 r=%221%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-40" />
      
      <div className="relative z-10">
        {/* Header */}
        <header className="border-b border-white/10 bg-white/5 backdrop-blur-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">Multi-Agent AI System</h1>
                  <p className="text-sm text-gray-400">Google ADK Powered Intelligence</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 text-gray-400 hover:text-white transition-colors duration-200"
                >
                  <Github className="w-5 h-5" />
                </a>
                <a
                  href="#docs"
                  className="flex items-center space-x-1 px-3 py-1 text-sm text-gray-300 hover:text-white border border-white/20 rounded-lg hover:border-white/40 transition-all duration-200"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Docs</span>
                </a>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
          {/* Introduction */}
          {!currentPlan && (
            <div className="text-center space-y-4 py-12">
              <div className="inline-flex p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full border border-purple-500/30">
                <Brain className="w-12 h-12 text-purple-400" />
              </div>
              <h2 className="text-4xl font-bold text-white">
                Intelligent Multi-Agent System
              </h2>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
                Experience the power of coordinated AI agents working together to achieve complex goals. 
                Each agent specializes in different tasks and enriches the output of previous agents 
                until your objective is fully realized.
              </p>
              <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-400 pt-4">
                <span className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-purple-400 rounded-full" />
                  <span>Strategic Planning</span>
                </span>
                <span className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-400 rounded-full" />
                  <span>Data Enrichment</span>
                </span>
                <span className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full" />
                  <span>Intelligent Analysis</span>
                </span>
                <span className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-orange-400 rounded-full" />
                  <span>Goal Achievement</span>
                </span>
              </div>
            </div>
          )}

          {/* Goal Input */}
          <GoalInput onSubmit={handleGoalSubmit} isExecuting={isExecuting} />

          {/* Execution Flow */}
          {currentPlan && (
            <div className="space-y-8">
              <ExecutionFlow plan={currentPlan} />
              <ResultsSummary plan={currentPlan} />
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className="border-t border-white/10 bg-white/5 backdrop-blur-md mt-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
              <div className="text-gray-400 text-sm">
                Built with React, TypeScript, and Tailwind CSS
              </div>
              <div className="flex items-center space-x-6 text-sm text-gray-400">
                <span>APIs: SpaceX • OpenWeather • NewsAPI</span>
                <span>•</span>
                <span>Google ADK Integration</span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;